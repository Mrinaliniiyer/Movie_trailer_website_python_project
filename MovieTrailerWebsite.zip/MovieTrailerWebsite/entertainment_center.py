# coding: utf-8

# In[3]:
import media
import fresh_tomatoes

# create instances of different genres of movie.

insideout = media.Movie("Inside out",
'''Eleven-year-old Riley has moved to San Francisco.
She and her five core emotions, Fear,
Anger, Joy, Disgust and Sadness, struggle to cope
with her new life. ''',
                        "https://m.media-amazon.com/images/M/MV5BMjAyNDg5MjEwMl5BMl5BanBnXkFtZTgwODQyNDM5NTE@._V1_UX477_CR0,0,477,268_AL_.jpg",   # noqa
                        "https://www.youtube.com/watch?v=yRUAzGQ3nSY",
                        "animation")

Stuart_little = media.Movie("Stuart_little",
                            '''The Little family adopts a brother for their
                            son, George, in the form of Stuart, a mouse who
                            can talk and be just like humans.''',
                            "https://images-na.ssl-images-amazon.com/images/I/51F2qZczpwL._SX383_BO1,204,203,200_.jpg",   # noqa
                            "https://www.youtube.com/watch?v=ZzuuziqAzXk",
                            "animation")

the_incredibles = media.Movie("the_incredibles",
                              '''The Incredibles is a 2004 American
                              computer-animated superhero film.''',
                              "https://images-na.ssl-images-amazon.com/images/I/716RrNAAMQL._SY445_.jpg",   # noqa
                              "https://www.youtube.com/watch?v=-UaGUdNJdRQ",
                              "animation")

the_nun = media.Movie("the_nun",
                      ''' American gothic supernatural horror film
                      directed by Corin Hardy.''',
                      '''https://i.ytimg.com/vi/zwAM5UnGd2s/maxresdefault.jpg''',  # noqa
                      "https://www.youtube.com/watch?v=pzD9zGcUNrw", "horror")

conjuring = media.Movie("conjuring",
                        '''Rod and Carolyn find their pet dog dead
                        under mysterious circumstances and experience
                        a spirit that harms their daughter Andrea.''',
                        "https://s3-ap-southeast-2.amazonaws.com/fna-wordpress-website06/wp-content/uploads/2018/08/07105756/ConjuringThe960x1440.jpg",  # noqa
                        "https://www.youtube.com/watch?v=k10ETZ41q5o",
                        "horror")

mama = media.Movie("Mama",
                   '''Two girls reside in a jungle after their parents
                   get murdered. When they are rescued years
                   later and begin a new life, they find that a shadowy
                   feminine figure has accompanied them to their house ''',
                   "https://a.ltrbxd.com/resized/sm/upload/ph/ik/j6/b9/kFMrQCo0Ue9GkeptoiB65FwF0lg-0-230-0-345-crop.jpg?k=45f3d69370",  # noqa
                   "https://www.youtube.com/watch?v=7Am7i7uM9r0",
                   "horror")

dunkirk = media.Movie("dunkirk",
                      ''''During World War II, soldiers from the British Empire,
                    Belgium and France try to evacuate from the town of Dunkirk
                    during a arduous battle . ''',
                   "https://upload.wikimedia.org/wikipedia/en/1/15/Dunkirk_Film_poster.jpg",  # noqa
                   "https://www.youtube.com/watch?v=F-eMt3SrfFU",
                   "war")

american_sniper = media.Movie("American Sniper",
                              '''Even after returning home from the war in Iraq,
                              Chris Kyle, a SEAL sniper, cannot let go of
                              the horrors
                              he has experienced.
                              This begins to affect his marriage
                              and his life.''',
                              "http://www.gstatic.com/tv/thumb/v22vodart/10991238/p10991238_v_v8_aa.jpg",  # noqa
                              "https://www.youtube.com/watch?v=99k3u9ay1gs",
                              "war")


threehundred = media.Movie("300",
                           '''In the ancient battle of Thermopylae, King Leonidas
                           and
                           300 Spartans fight against Xerxes
                           and his massive Persian army. They face
                           insurmountable odds when
                           they are betrayed by a Spartan reject.''',
                           "https://nerdbasego.files.wordpress.com/2014/03/300-rise-of-an-empire-artemisia1.jpg",  # noqa
                           "https://www.youtube.com/watch?v=UrIbxk7idYA",
                           "war")

saw = media.Movie("saw",
                  ''' Two men awaken to find themselves on the opposite sides
                    of a dead body, each with specific instructions to kill the
                    other or face consequences.''',
                  "https://m.media-amazon.com/images/M/MV5BMjE4MDYzNDE1OV5BMl5BanBnXkFtZTcwNDY2OTYwNA@@._V1_UX182_CR0,0,182,268_AL_.jpg",  # noqa
                  "https://www.youtube.com/watch?v=HKPy5RWuqNA",
                  "thriller")

final_destination = media.Movie("final_destination",
'''Alex saves his school friends from death when
                                he gets a premonition that their plane
                                will crash.''',
                                "https://m.media-amazon.com/images/M/MV5BZTI0NGM2OGYtNzVmMi00NGQ2LTk2MDAtN2RmYjIzMGRkZGYxXkEyXkFqcGdeQXVyNTAyODkwOQ@@._V1_.jpg",  # noqa
                                "https://www.youtube.com/watch?v=Nqs07Fn2vzg",
                                "thriller")

dont_breathe = media.Movie("dont_breathe",
                           ''' A troika of robbers barges into the house of a
                           visually-impaired veteran after hearing that
                           he has won prize money.''',
                           "https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Don%27t_Breathe_%282016_film%29.png/220px-Don%27t_Breathe_%282016_film%29.png",  # noqa
                           "https://www.youtube.com/watch?v=76yBTNDB6vU",
                           "thriller")

thor = media.Movie("thor",
                   '''Thor is exiled by his father Odin, the King of Asgard,
                   to the Earth to live among mortals. ''',
                   "https://static0.srcdn.com/wordpress/wp-content/uploads/2017/02/Thor-The-Dark-World-Convergence.jpg",  # noqa
                   "https://www.youtube.com/watch?v=JOddp-nlNvQ",
                   "action")

avengers_endgame = media.Movie("avengers_endgame",
                               '''The Avengers take a final stand against Thanos
                                in Marvel Studios ''',
                               "https://cdn3.movieweb.com/i/article/9z79GqA5pXxi9wwp2IexKuZvggyppK/798:50/Avengers-4-Endgame-Trailer.jpg",  # noqa
                               "https://www.youtube.com/watch?v=TcMBFSGVi1c",
                               "action")

deadpool = media.Movie("deadpool",
                       '''Mercenary Wade Wilson, subjected to an experiment to
                       heal himself of cancer, obtains healing powers. ''',
                       "https://upload.wikimedia.org/wikipedia/en/thumb/2/23/Deadpool_%282016_poster%29.png/220px-Deadpool_%282016_poster%29.png",  # noqa
                       "https://www.youtube.com/watch?v=9vN6DHB6bJc",
                       "action")

exam = media.Movie("exam",
                   '''Eight candidates cooperate in order to secure a job
                   with a prestigious company. ''',
                   "https://upload.wikimedia.org/wikipedia/en/thumb/0/09/Exam_poster.jpg/220px-Exam_poster.jpg",  # noqa
                   "https://www.youtube.com/watch?v=bkdt2Sygew0",
                   "scifi")

life = media.Movie("life",
                   '''As astronauts discover the first evidence of
                   extra-terrestrial life on Mars, they begin realising
                   that the life form is extremely intelligent and
                   hostile. ''',
                   "https://upload.wikimedia.org/wikipedia/en/c/c4/Life_%282017_film%29.png",  # noqa
                   "https://www.youtube.com/watch?v=dgOGqWHtjP0",
                   "scifi")

gravity = media.Movie("gravity",
                   '''An engineer on her first time on a space mission, and an astronaut on his final expedition, have to survive in space. ''',   # noqa
                   "https://i.ytimg.com/vi/vZUyxkNMEeU/maxresdefault.jpg",
                   "https://www.youtube.com/watch?v=0-eP-W0DNmY",
                   "scifi")

# define a dictionary  called movies which stores the movies as keys with its
# genre as its value

movies = {
    insideout: "animation",
    Stuart_little: "animation",
    the_incredibles: "animation",
    the_nun: "horror",
    conjuring: "horror",
    mama: "horror",
    dunkirk: "war",
    american_sniper: "war",
    threehundred: "war",
    saw: "thriller",
    final_destination: "thriller",
    dont_breathe: "thriller",
    thor: "action",
    avengers_endgame: "action",
    deadpool: "action",
    exam: "scifi",
    life: "scifi",
    gravity: "scifi"}
fresh_tomatoes.open_movies_page(movies)
